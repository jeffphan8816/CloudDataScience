#!/bin/sh
cp -r ${SRC_PKG} ${DEPLOY_PKG}
